

/**
 * A general class for tic tac toe players. 
 */
public class TicTacToe5x5Player {
    private char symbol;
    
    public TicTacToe5x5Player(char symbol) {
        this.symbol = symbol;
    }
    
    public char getSymbol() {
        return this.symbol;
    }
    
    public String toString() {
        return Character.toString(symbol);
    }

    /**
     * Gets the heuristic score from a player for a given state. This score
     * should roughly estimate how close the player is to winning.
     * 
     * @param state
     * @return
     */
    public int getHeuristicScore(TicTacToe5x5State state) {
        boolean[][] board = getMatchedBoard(state.getBoard()); 
        boolean[][] rotatedBoard = rotate(board);
        int maxScore = 0;
        maxScore = Math.max(maxScore, getMaxRowSequence(board));
        maxScore = Math.max(maxScore, getMaxRowSequence(rotatedBoard));
        maxScore = Math.max(maxScore, DotMatrix.maxDiagonalAlignment(board));
        maxScore = Math.max(maxScore, DotMatrix.maxDiagonalAlignment(rotatedBoard));
        return maxScore;
    }
    
    /**
     * Returns a matched board where each square is true if it belongs to this player.
     * 
     * @param board
     * @return
     */
    private boolean[][] getMatchedBoard(char[][] board) {
        boolean[][] matchedBoard = new boolean[board.length][board[0].length];
    
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                matchedBoard[row][col] = board[row][col] == symbol;
            }
        }
        return matchedBoard;
    }
    
    /**
     * Checks for a max row sequence.
     * 
     * @param board
     * @return
     */
    private int getMaxRowSequence(boolean[][] board) {
        int maxSequence = 0;
        for (boolean[] row : board) {
            int currentSequence = 0;
            for (boolean playersSquare : row) {
                // we are looping down the row looking for a sequence of chars == player
                if (playersSquare) {
                    currentSequence++;
                }
                else {
                    // the square does not belong to player
                    maxSequence = Math.max(maxSequence, currentSequence);
                    currentSequence = 0;
                }
            }
            maxSequence = Math.max(maxSequence, currentSequence);
        }
        return maxSequence;
    }
    
   
    /**
     * Returns a matrix "rotated" 90 degrees.
     * 
     * @param board
     * @return
     */
    private boolean[][] rotate(boolean[][] board) {
        boolean[][] result = new boolean[board.length][board[0].length];
        for (int row = 0; row < board.length; row++) {
            for (int col = 0; col < board[row].length; col++) {
                result[col][board.length - row - 1] = board[row][col];
            }
        }
        return result;
    }
}

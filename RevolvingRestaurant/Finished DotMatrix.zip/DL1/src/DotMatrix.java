
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.junit.Test;
import static org.junit.Assert.*;

public class DotMatrix {
    // Some sample DNA sequences
    public static final char[] TEST1 = "AGTA".toCharArray();
    public static final char[] TEST2 = "AAGT".toCharArray();
    
    public static final char[] SAMPLE1 = "AGTGCTGAAAGTTGCGCCAGTGAC".toCharArray();
    public static final char[] SAMPLE2 = "AGTGCTGAAGTTCGCCAGTTGACG".toCharArray();
    
    /**
     * Computes the Dot Matrix of the two sequences.
     * Returns a boolean matrix where a match between seq1 and seq2 at a position
     * would be true, otherwise false.
     * 
     * @param seq1
     * @param seq2
     * @return
     */
    public static boolean[][] computeDotMatrix(char[] seq1, char[] seq2) {
        boolean[][] result = new boolean[seq1.length][seq2.length];
        for(int i=0;i<seq1.length;i++){
        	for(int j=0;j<seq2.length;j++){
        		if(seq1[i]==seq2[j]){
        			result[i][j]=true;
        		}
        		else{
        			result[i][j]=false;
        		}
        	}
        }
        
        // you need to complete this method   
        return result;
    }
    
   
    
    /**
     * Computes the maximum diagonal alignment by looking at each diagonal
     * left-to-right and checking how many matches in a sequence it can find.
     * 
     * @param dotMatrix
     * @return the max diagonal alignment score
     */
    public static int maxDiagonalAlignment(boolean[][] dotMatrix) {
        int score = 0;
        for(int i=0;i<dotMatrix.length;i++){
        	for(int j=0;j<dotMatrix[i].length;j++){
        		int currentScore=0;
        		int k=i;
        		int l=j;
        		while(k<dotMatrix.length && l<dotMatrix[k].length && dotMatrix[k][l]==true){
        			currentScore++;
        			k++;
        			l++;
        		}
        		if(currentScore>score){
        			score=currentScore;
        		}     	
        	}   		
        }      
        // you need to complete this method
        // HINT: you can make this easier by writing a helper method that
        //       finds the maximum sequence for a diagonal that starts at
        //       some position x,y and then call it for all possible starting
        //       positions       
        return score;
    }

    /**
     * Prints a dot matrix representation of two sequences being aligned. Prints the
     * seq1 value down the leftmost column, and seq2 above the topmost row. Prints an
     * x at every place that is true in the dotMatrix.
     * 
     * @param seq1
     * @param seq2
     * @param dotMatrix
     */
    public static void print(char[] seq1, char[] seq2, boolean[][] dotMatrix) {
        System.out.print("  ");
        for (int i = 0; i < seq2.length; i++) {
            System.out.print(seq2[i]);
            System.out.print(" ");
        }
        System.out.println();
        
        System.out.print(" +");
        for (int i = 0; i < seq2.length; i++) {
            System.out.print("--");
        }
        System.out.println();
        
        for (int i = 0; i < seq1.length; i++) {
            System.out.print(seq1[i]);
            System.out.print("|");
            for (int j = 0; j < seq2.length; j++) {
                System.out.print(dotMatrix[i][j] ? "x" : " ");
                System.out.print(" ");
            }
            System.out.println();
        }
    }

    /**
     * A JUnit test for your compute method.
     * 
     * You do not need to modify this method.
     */
    @Test
    public void test_compute() {
        // Tests if compute generates correct result when given TEST1 and TEST2
        boolean[][] expected = {{true, true, false, false},
                                {false, false, true, false},
                                {false, false, false, true},
                                {true, true, false, false}};
        boolean[][] result = computeDotMatrix(TEST1, TEST2);
        // print(TEST1, TEST2, result);
        
        assertTrue("expected:" + Arrays.deepToString(expected) + " but was:" +
                   Arrays.deepToString(result),
                   Arrays.deepEquals(expected, result));
    }
    
    /**
     * A JUnit test for your maxDiagonalAlignment method.
     * 
     * You do not need to modify this method.
     */
    @Test
    public void test_maxDiagonalAlignment() {
        // Tests if maxDiagonalAlignment generates correct result when given 
        // the correct output of compute(TEST1, TEST2)
        assertEquals(3, maxDiagonalAlignment(computeDotMatrix(TEST1, TEST2)));
        assertEquals(9, maxDiagonalAlignment(computeDotMatrix(SAMPLE1, SAMPLE2)));
    }
    
    /**
     * Reads a specific genome sequence file format.  Scans comment lines for information
     * about locations, and parses sequences into the given array lists.
     * 
     * @param fileName
     * @param sequences
     * @param locations
     * @throws Exception
     */
    public static void loadSequencesFromFile(String fileName, 
                                             ArrayList<String> sequences, 
                                             ArrayList<String> locations) throws Exception {
        Scanner in = new Scanner(new File(fileName));
        in.useDelimiter("\r\n|[\n\r]"); // parse each line in the file
        
        while (in.hasNext()) {
            String line = in.next();
            if (line.startsWith(";")) {
                // it is a comment, check to see if it marks a location
                if (line.startsWith(";A")) {
                    // get the location information
                    locations.add(line.split("/")[1]);
                }
            }
            else if (line.length() != 0) { // it is not empty
                // convert the lower case format to upper case and remove blanks
                sequences.add(line.toUpperCase().replace(" ", ""));
            }
        }
    }
    
    private static int findClosestMatch(String sequence, ArrayList<String> sequences) {
        char[] sequenceArray = sequence.toCharArray();
        int maxScore = -1;
        int maxScoreSequence = -1;
        for (int i = 0; i < sequences.size(); i++) {
            // don't allow it to compare to itself
            if (sequence != sequences.get(i)) {
                boolean[][] dotMatrix = computeDotMatrix(
                    sequenceArray, sequences.get(i).toCharArray());
                int score = maxDiagonalAlignment(dotMatrix);
                System.out.println(score);
                if (score > maxScore) {
                    maxScore = score;
                    maxScoreSequence = i;
                }
            }
        }
        return maxScoreSequence;
    }
    
    public static void main(String[] args) throws Exception {
        ArrayList<String> sequences = new ArrayList<String>();
        ArrayList<String> locations = new ArrayList<String>();
        loadSequencesFromFile("./src/influenza.txt", sequences, locations);

        System.out.println("Determining which sequence is the most likely known source of the " +
            locations.get(0) + " influenza strain...");

        // assume the first sequence is the test, we want to find which 
        //  other sequence is its closest match
        int closestMatch = findClosestMatch(sequences.get(0), sequences);
        
        System.out.println("The closest match and most likely known source of the " + 
            locations.get(0) + " influenza strain is " + locations.get(closestMatch));
        
    }
}

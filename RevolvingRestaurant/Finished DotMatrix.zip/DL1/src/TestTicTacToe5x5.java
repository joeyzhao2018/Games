

import org.junit.Test;
import static org.junit.Assert.*;

public class TestTicTacToe5x5 {
    // an example empty board (score 0 for x, 0 for o)
    public static final char[][] BOARD0 = 
    {{' ', ' ', ' ', ' ', ' '},
     {' ', ' ', ' ', ' ', ' '},
     {' ', ' ', '#', ' ', ' '},
     {' ', ' ', ' ', ' ', ' '},
     {' ', ' ', ' ', ' ', ' '}};
    
    // an example board after 2 turns each (score 1 for x, 2 for o)
    public static final char[][] BOARD1 = 
    {{'x', ' ', ' ', ' ', ' '},
     {' ', ' ', ' ', ' ', 'o'},
     {' ', ' ', '#', 'o', ' '},
     {'x', ' ', ' ', ' ', ' '},
     {' ', ' ', ' ', ' ', ' '}};
                                       
    // an example board mid-game (score 2 for x, 3 for o)
    public static final char[][] BOARD2 = 
    {{'x', 'o', 'o', ' ', 'x'},
     {'x', ' ', 'o', ' ', 'o'},
     {' ', ' ', '#', 'o', ' '},
     {'x', 'o', 'x', 'x', ' '},
     {' ', ' ', ' ', ' ', ' '}};

    // an example board where player x has won (score 4 for x, 3 for o)
    public static final char[][] BOARD3 = 
    {{'x', 'o', 'o', ' ', 'x'},
     {'x', ' ', 'o', ' ', 'o'},
     {'x', ' ', '#', 'o', ' '},
     {'x', 'o', 'x', 'x', ' '},
     {' ', ' ', ' ', ' ', ' '}};
    
    // an example board where nobody has won (score 3 for x, 3 for o) but there are no more moves
    public static final char[][] BOARD4 = 
    {{'x', 'o', 'o', 'o', 'x'},
     {'o', 'o', 'o', 'x', 'o'},
     {'x', 'x', '#', 'o', 'x'},
     {'x', 'o', 'x', 'x', 'x'},
     {'o', 'x', 'o', 'o', 'x'}};
    
    @Test
    public void test_getHeuristicScore() {
        TicTacToe5x5Player playerX = new TicTacToe5x5Player('x');
        TicTacToe5x5Player playerO = new TicTacToe5x5Player('o');
        TicTacToe5x5State board0 = new TicTacToe5x5State(BOARD0, playerX);
        TicTacToe5x5State board1 = new TicTacToe5x5State(BOARD1, playerX);
        TicTacToe5x5State board2 = new TicTacToe5x5State(BOARD2, playerX);
        TicTacToe5x5State board3 = new TicTacToe5x5State(BOARD3, playerX);
        TicTacToe5x5State board4 = new TicTacToe5x5State(BOARD4, playerX);

        assertEquals(0, playerX.getHeuristicScore(board0));
        assertEquals(0, playerO.getHeuristicScore(board0));
        assertEquals(1, playerX.getHeuristicScore(board1));
        assertEquals(2, playerO.getHeuristicScore(board1));
        assertEquals(2, playerX.getHeuristicScore(board2));
        assertEquals(3, playerO.getHeuristicScore(board2));
        assertEquals(4, playerX.getHeuristicScore(board3));
        assertEquals(3, playerO.getHeuristicScore(board3));
        assertEquals(3, playerX.getHeuristicScore(board4));
        assertEquals(3, playerO.getHeuristicScore(board4));
    }
    
    @Test
    public void test_isEnd() {
        TicTacToe5x5Player playerX = new TicTacToe5x5Player('x');
        TicTacToe5x5State board0 = new TicTacToe5x5State(BOARD0, playerX);
        TicTacToe5x5State board1 = new TicTacToe5x5State(BOARD1, playerX);
        TicTacToe5x5State board2 = new TicTacToe5x5State(BOARD2, playerX);
        TicTacToe5x5State board3 = new TicTacToe5x5State(BOARD3, playerX);
        TicTacToe5x5State board4 = new TicTacToe5x5State(BOARD4, playerX);

        assertFalse(board0.isEnd());
        assertFalse(board1.isEnd());
        assertFalse(board2.isEnd());
        assertFalse(board3.isEnd());
        assertTrue(board4.isEnd());
    }
    
    public static void main(String[] args) {
        // print the state
        TicTacToe5x5Player playerX = new TicTacToe5x5Player('x');
        TicTacToe5x5State board0 = new TicTacToe5x5State(BOARD0, playerX);
        TicTacToe5x5State board1 = new TicTacToe5x5State(BOARD1, playerX);
        TicTacToe5x5State board2 = new TicTacToe5x5State(BOARD2, playerX);
        TicTacToe5x5State board3 = new TicTacToe5x5State(BOARD3, playerX);
        TicTacToe5x5State board4 = new TicTacToe5x5State(BOARD4, playerX);
        board0.print();
        board1.print();
        board2.print();
        board3.print();
        board4.print();
    }
}



public class TicTacToe5x5State {
    private char[][] board;
    private TicTacToe5x5Player turn;
    
    public TicTacToe5x5State(char[][] board, TicTacToe5x5Player turn) {
        this.board = board;
        this.turn = turn;
    }
    
    public char[][] getBoard() {
        return board;
    }
    
    public TicTacToe5x5Player getTurn() {
        return turn;
    }

    /**
     * Determines if the board is an end state (i.e. no further moves
     * can be made).  For TicTacToe this method returns true if there are
     * no empty spaces on the board.
     * 
     * @return
     */
    public boolean isEnd() {
        boolean emptySpace = false;
        for (char[] row : board) {
            for (char value : row) {
                if (value == ' ') {
                    emptySpace = true;
                }
            }
        }
        return !emptySpace;
    }
    
    /**
     * Prints a visual representation of a TicTacToe5x5 board
     */
    public void print() {
        System.out.println("Player " + turn + "'s turn");
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }
}
